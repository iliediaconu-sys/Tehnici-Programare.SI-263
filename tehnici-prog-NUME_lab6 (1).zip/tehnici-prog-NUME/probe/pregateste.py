"""Generează țintele de laborator în probe/. Rulează din rădăcina depozitului:
    python probe/pregateste.py
"""
import base64, hashlib, io, zipfile
from pathlib import Path
from PIL import Image, ImageDraw
from PIL.PngImagePlugin import PngInfo
from PIL.TiffImagePlugin import IFDRational

PROBE = Path(__file__).resolve().parent


def url_total(b: bytes) -> str:
    """Percent-encode la TOATE caracterele (ca să apară clar un strat 'url')."""
    return "".join(f"%{x:02x}" for x in b)


# 1) mesaj.txt: clar -> hex -> base64 -> url (se desface în ordine inversă)
clar = b"FLAG{straturile_se_desfac_pe_rand}"
strat = url_total(base64.b64encode(clar.hex().encode()))
(PROBE / "mesaj.txt").write_text(strat + "\n")

# 2) xor.bin: text criptat cu XOR pe un singur octet
text = (b"FLAG{xor_cu_cheie_de_un_octet_se_sparge_in_256_de_incercari} "
        b"Cheia are doar 256 de valori posibile.")
cheie = 173
(PROBE / "xor.bin").write_bytes(bytes(b ^ cheie for b in text))

# 3) hashuri.txt (+ wordlist.txt): md5, sha1, sha256 de parole slabe
parole = [("md5", "sunshine"), ("sha1", "football"), ("sha256", "master")]
(PROBE / "hashuri.txt").write_text(
    "\n".join(hashlib.new(alg, p.encode()).hexdigest() for alg, p in parole) + "\n")
wordlist = """123456 password qwerty abc123 letmein monkey dragon 111111 baseball iloveyou
trustno1 sunshine princess welcome shadow superman michael football jesus ninja
mustang master hello freedom whatever qazwsx login starwars passw0rd zaq1zaq1
admin chisinau moldova utm securitate parola secret flag""".split()
(PROBE / "wordlist.txt").write_text("\n".join(wordlist) + "\n")

# 4) foto.jpg cu EXIF + GPS (47.0105 N, 28.8638 E)
img = Image.new("RGB", (640, 480))
px = img.load()
for y in range(480):
    for x in range(640):
        px[x, y] = (x * 255 // 639, y * 255 // 479, (x + y) * 255 // 1118)
d = ImageDraw.Draw(img)
d.ellipse((220, 140, 420, 340), outline=(255, 255, 255), width=6)
d.text((250, 235), "UTM FCIM LAB 6", fill=(255, 255, 255))


def dms(valoare):
    g = int(valoare)
    m = int((valoare - g) * 60)
    s = round(((valoare - g) * 60 - m) * 60 * 100)
    return (IFDRational(g, 1), IFDRational(m, 1), IFDRational(s, 100))


exif = Image.Exif()
exif[0x010F] = "LabCam"            # Make
exif[0x0110] = "Model X1"          # Model
exif[0x0132] = "2025:10:06 10:15:00"  # DateTime
gps = exif.get_ifd(0x8825)
gps[1], gps[2] = "N", dms(47.0105)
gps[3], gps[4] = "E", dms(28.8638)
img.save(PROBE / "foto.jpg", quality=92, exif=exif)

# 5) ascuns.png: PNG valid cu un ZIP lipit la coadă (+ un indiciu în tEXt)
meta = PngInfo()
meta.add_text("Comment", "nu tot ce e in fisier se vede in imagine")
png = io.BytesIO()
Image.new("RGB", (200, 120), (30, 60, 120)).save(png, "PNG", pnginfo=meta)
zbuf = io.BytesIO()
with zipfile.ZipFile(zbuf, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("secret.txt", "FLAG{fisier_ascuns_la_coada_png}\n")
(PROBE / "ascuns.png").write_bytes(png.getvalue() + zbuf.getvalue())

# 6) challenge.bin (opțional): base64( XOR(flag) ) + sha256(flag) pentru verificare
flag = b"FLAG{xor_si_base64_si_un_hash_de_verificat}"
xorat = bytes(b ^ 91 for b in flag)
(PROBE / "challenge.bin").write_bytes(
    base64.b64encode(xorat) + b"\n" + hashlib.sha256(flag).hexdigest().encode() + b"\n")

print("Gata, fisiere in", PROBE)
