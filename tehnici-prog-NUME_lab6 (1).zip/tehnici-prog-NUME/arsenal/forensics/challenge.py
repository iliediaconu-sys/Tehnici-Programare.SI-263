"""Optional (varful salii): probe/challenge.bin, rezolvat fara schelet.
Pasi: (1) file/strings arata 2 linii ASCII; (2) linia 1 e base64 -> octeti ne-citibili;
(3) octetii nu sunt text => probabil XOR cu un octet; (4) incerc 256 chei;
(5) linia 2 are 64 hex = sha256: verific care candidat are exact acel hash.
"""
import base64
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
linia1, linia2 = Path(ROOT / "probe" / "challenge.bin").read_text().split()
cifrat = base64.b64decode(linia1)
for k in range(256):
    clar = bytes(b ^ k for b in cifrat)
    if hashlib.sha256(clar).hexdigest() == linia2:       # verificare exacta, nu euristica
        print("cheie:", k, "| flag:", clar.decode())
        break
