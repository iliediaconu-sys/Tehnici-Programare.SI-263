"""Lucrarea B1-B4: magic bytes, strings, EXIF/GPS, file carving.
Ruleaza din radacina depozitului:  python arsenal/forensics/forensics.py
Se lucreaza DOAR pe fisierele din probe/ (generate de pregateste.py).
"""
import io
import re
import zipfile
from pathlib import Path
from PIL import Image
from PIL.ExifTags import TAGS

ROOT = Path(__file__).resolve().parents[2]
PROBE = ROOT / "probe"


# ---------- B1: tipul real, dupa semnatura, nu dupa extensie ----------
SEMNATURI = [
    (b"%PDF", "pdf"),
    (b"\x89PNG", "png"),
    (b"\xff\xd8", "jpeg"),
    (b"PK\x03\x04", "zip/docx"),
    (b"GIF8", "gif"),
]


def tip_real(cale):
    with open(cale, "rb") as f:             # "rb" obligatoriu: altfel octetii se pot altera
        cap = f.read(8)
    for semn, nume in SEMNATURI:
        if cap.startswith(semn):
            return nume
    return cap.hex()


# ---------- B2: strings ----------
def strings(cale, minim=4):
    date = Path(cale).read_bytes()
    return [m.decode() for m in re.findall(rb"[ -~]{%d,}" % minim, date)]


# ---------- B3: EXIF + GPS ----------
def dms_la_zecimal(dms, ref):
    g, m, s = (float(x) for x in dms)
    val = g + m / 60 + s / 3600
    return -val if ref in ("S", "W") else val


def exif_si_gps(cale):
    img = Image.open(cale)
    exif = img.getexif()
    meta = {TAGS.get(i, i): v for i, v in exif.items()}
    gps = exif.get_ifd(34853)                       # blocul GPS
    coord = None
    if gps:
        lat = dms_la_zecimal(gps[2], gps[1])
        lon = dms_la_zecimal(gps[4], gps[3])
        coord = (lat, lon)
    return meta, gps, coord


# ---------- B4: file carving ----------
def carve_zip(cale, iesire="gasit.zip"):
    date = Path(cale).read_bytes()
    start = date.find(b"IEND")                      # cautam DUPA sfarsitul PNG-ului real
    i = date.find(b"PK\x03\x04", start if start != -1 else 0)
    if i == -1:
        return None
    Path(iesire).write_bytes(date[i:])
    continut = {}
    with zipfile.ZipFile(io.BytesIO(date[i:])) as z:
        for nume in z.namelist():
            continut[nume] = z.read(nume).decode(errors="replace")
    return i, continut


if __name__ == "__main__":
    print("== B1 tip real ==")
    for f in ["foto.jpg", "ascuns.png", "xor.bin", "mesaj.txt"]:
        print(f"{f:12s} -> {tip_real(PROBE / f)}")

    print("\n== B2 strings(ascuns.png) ==")
    for s in strings(PROBE / "ascuns.png"):
        print(" ", s)

    print("\n== B3 EXIF + GPS (foto.jpg) ==")
    meta, gps, coord = exif_si_gps(PROBE / "foto.jpg")
    for k, v in meta.items():
        if k != "GPSInfo":
            print(f"  {k} = {v}")
    print("  GPS brut:", {k: (tuple(float(x) for x in v) if isinstance(v, tuple) else v)
                          for k, v in gps.items()})
    print("  lat, lon (grade zecimale): %.6f, %.6f" % coord)
    print("  harta: https://www.openstreetmap.org/?mlat=%.6f&mlon=%.6f" % coord)

    print("\n== B4 carving (ascuns.png) ==")
    gasit = carve_zip(PROBE / "ascuns.png", ROOT / "gasit.zip")
    if gasit:
        i, continut = gasit
        print("  arhiva extrasa de la octetul", i)
        for nume, text in continut.items():
            print(f"  {nume}: {text.strip()}")
