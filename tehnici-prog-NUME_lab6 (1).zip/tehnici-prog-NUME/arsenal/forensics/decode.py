"""Decoder universal: recunoaste stratul (url/hex/base64), il desface,
sparge XOR cu cheie de un octet si hash-uri de parola prin dictionar.

Utilizare (din radacina depozitului):
    python arsenal/forensics/decode.py "NTM1OTU3NTk="
    python arsenal/forensics/decode.py probe/mesaj.txt --fisier
    python arsenal/forensics/decode.py probe/xor.bin --fisier --xor
    python arsenal/forensics/decode.py probe/hashuri.txt --fisier --hash
"""
import argparse
import base64
import binascii
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote_to_bytes

ROOT = Path(__file__).resolve().parents[2]
WORDLIST = ROOT / "probe" / "wordlist.txt"
FISA = Path(__file__).resolve().parent / "fisa.json"


# ---------- A1: text vs octeti ----------
def demo_text_octeti():
    s = "Salut"
    b = s.encode()
    print(b, b[0])                     # b'Salut' 83  (b[0] e numar, nu litera)
    print(b.hex(), bytes.fromhex(b.hex()))


# ---------- A2: recunoasterea stratului dupa forma ----------
def ghici_strat(s):
    # Ordinea conteaza: % (url) -> hex (mai strict) -> base64 (alfabet mai larg)
    if re.search(r"%[0-9a-fA-F]{2}", s):
        return "url"
    if re.fullmatch(r"[0-9a-fA-F]+", s) and len(s) % 2 == 0:
        return "hex"
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", s) and len(s) % 4 == 0:
        return "base64"
    return "necunoscut"


# ---------- A3: desfacerea stratului ----------
def desfa(s):
    strat = ghici_strat(s)
    try:
        if strat == "base64":
            return strat, base64.b64decode(s, validate=True)
        if strat == "hex":
            return strat, bytes.fromhex(s)
        if strat == "url":
            return strat, unquote_to_bytes(s)      # unquote(s).encode() pierde octetii non-UTF8
    except (binascii.Error, ValueError):
        pass
    return "necunoscut", s.encode()


# ---------- A4: straturi multiple ----------
def citibil(b):
    return len(b) > 0 and all(32 <= c < 127 for c in b)


def desfa_complet(val, max_straturi=8):
    """Desface in bucla. Un strat se accepta doar daca rezultatul e text citibil;
    altfel valoarea curenta e deja textul final (ex. 'Test' e alfabet base64,
    dar decodat da octeti ne-citibili -> nu era base64)."""
    cur = val.encode() if isinstance(val, str) else val
    straturi = []
    for _ in range(max_straturi):
        try:
            s = cur.decode("ascii").strip()
        except UnicodeDecodeError:
            break
        strat, b = desfa(s)
        if strat == "necunoscut" or not citibil(b):
            break
        straturi.append(strat)
        cur = b
    return straturi, cur


# ---------- A5: XOR cu cheie de un octet ----------
FRECVENTE = b"etaoinshrdlu "     # cele mai frecvente litere + spatiul


def scor_text(b):
    """Cat de mult seamana cu text omenesc. Prima varianta (fractia de caractere
    alfanumerice) alegea o cheie GRESITA: o cheie apropiata de cea buna da si ea
    'text' printabil. Deci punctam literele frecvente si dam bonus formatului FLAG{."""
    scor = sum(c in FRECVENTE for c in b) / len(b)
    return scor + (1 if b.startswith(b"FLAG{") else 0)


def sparge_xor(date):
    candidati = []
    for k in range(256):
        clar = bytes(b ^ k for b in date)
        if citibil(clar):
            candidati.append((scor_text(clar), k, clar))
    return sorted(candidati, reverse=True)       # cel mai "text" primul


# ---------- A6: hash prin dictionar ----------
ALGO = {32: "md5", 40: "sha1", 64: "sha256"}


def sparge_hash(tinta, wordlist=WORDLIST):
    alg = ALGO.get(len(tinta))
    if not alg:
        return None, None
    for cuv in open(wordlist, encoding="latin1"):
        cuv = cuv.strip()
        if hashlib.new(alg, cuv.encode()).hexdigest() == tinta.lower():
            return alg, cuv
    return alg, None


# ---------- A7: CLI + fisa JSON ----------
def main():
    p = argparse.ArgumentParser(description="Decoder universal pentru forensics")
    p.add_argument("intrare")                      # sir sau cale
    p.add_argument("--fisier", action="store_true")
    p.add_argument("--xor", action="store_true", help="sparge XOR cu cheie de un octet")
    p.add_argument("--hash", action="store_true", help="sparge hash-urile din fisier")
    a = p.parse_args()

    if a.fisier:
        date = Path(a.intrare).read_bytes()
    else:
        date = a.intrare.encode()

    if a.xor:
        cand = sparge_xor(date)
        for scor, k, clar in cand[:3]:
            print(f"cheie: {k:3d} (0x{k:02x})  scor: {scor:.2f}  -> {clar.decode()}")
        return
    if a.hash:
        for linie in date.decode().split():
            alg, parola = sparge_hash(linie)
            print(f"{alg or '?':7s} {linie[:16]}...  ->  {parola or 'negasit'}")
        return

    straturi, rezultat = desfa_complet(date.decode(errors="replace"))
    print("straturi:", " -> ".join(straturi) or "(niciunul)")
    print("rezultat:", rezultat.decode(errors="replace"))
    FISA.write_text(json.dumps(
        {"intrare": date.decode(errors="replace").strip(),
         "strat": straturi[0] if straturi else "necunoscut",
         "straturi": straturi,
         "rezultat": rezultat.decode(errors="replace")},
        indent=2, ensure_ascii=False) + "\n")
    print("fisa salvata in", FISA.relative_to(ROOT))


if __name__ == "__main__":
    main()
