"""Lucrarea B5-B6: steganografie LSB (cel mai putin semnificativ bit al canalelor RGB).
    python arsenal/forensics/stego.py            # ascunde in stego.png, apoi dezvaluie
Mesajul se termina cu un octet 0 (sfarsit de mesaj).
"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]


def ascunde(gazda, iesire, mesaj: bytes):
    img = Image.open(gazda).convert("RGB")
    canale = list(img.tobytes())                              # R,G,B,R,G,B,... (octeti)
    biti = "".join(f"{x:08b}" for x in mesaj + b"\x00")       # + terminator
    if len(biti) > len(canale):
        raise ValueError("mesaj prea lung pentru imaginea gazda")
    for i, bit in enumerate(biti):
        canale[i] = (canale[i] & ~1) | int(bit)               # inlocuim LSB
    Image.frombytes("RGB", img.size, bytes(canale)).save(iesire, "PNG")        # PNG = fara pierderi; JPG ar distruge bitii ascunsi


def dezvaluie(cale):
    canale = Image.open(cale).convert("RGB").tobytes()
    biti = "".join(str(c & 1) for c in canale)                # r&1, g&1, b&1 pe rand
    octeti = bytearray()
    for i in range(0, len(biti) - 7, 8):
        o = int(biti[i:i + 8], 2)
        if o == 0:                                            # primul octet 0 = final
            break
        octeti.append(o)
    return bytes(octeti)


if __name__ == "__main__":
    mesaj = b"FLAG{ascuns_in_pixeli}"
    gazda = ROOT / "probe" / "foto.jpg"
    iesire = ROOT / "stego.png"
    ascunde(gazda, iesire, mesaj)
    print("scris:", iesire.name)
    gasit = dezvaluie(iesire)
    print("dezvaluit:", gasit.decode())
    assert gasit == mesaj

    a = Image.open(gazda).convert("RGB")
    b = Image.open(iesire).convert("RGB")
    diff = max(abs(x - y) for x, y in zip(a.tobytes(), b.tobytes()))
    print("diferenta maxima pe un canal intre original si stego:", diff)
