# Raport — Laboratorul 6: Informații invizibile (forensics și steganografie)

Toate fișierele analizate au fost generate local de `probe/pregateste.py`
(ținte permise). Se rulează din rădăcina depozitului.

## Lucrarea A — Decoderul universal (`arsenal/forensics/decode.py`)

**Mesajul cu straturi** (`probe/mesaj.txt`): `url → base64 → hex`, apoi textul clar
`FLAG{straturile_se_desfac_pe_rand}`. Unealta a găsit singură ordinea; fișa e în
`arsenal/forensics/fisa.json`.

**XOR cu un octet** (`probe/xor.bin`): cheia este **173 (0xAD)**; textul era
`FLAG{xor_cu_cheie_de_un_octet_se_sparge_in_256_de_incercari} ...`.
Observație importantă: simpla condiție „toți octeții sunt 32..126" lasă să treacă
mai multe chei (172 și 171 dau și ele șiruri „printabile", dar fără sens), deci am
adăugat un scor (litere frecvente + spațiu + bonus pentru prefixul `FLAG{`) care
alege cheia corectă.

**Hash-uri** (`probe/hashuri.txt`, algoritmul identificat după lungime: 32=md5,
40=sha1, 64=sha256), sparte cu dicționarul `probe/wordlist.txt`:

| algoritm | parola găsită |
|---|---|
| md5 | `sunshine` |
| sha1 | `football` |
| sha256 | `master` |

Nu „decriptăm" hash-ul: hash-uim fiecare cuvânt și comparăm.

**Exemplul din fișă** `NTM1OTU3NTk=` → `base64 → hex` → `SYWY` (octeții
`53 59 57 59`; "SYWY" nu mai e codare validă, bucla se oprește).

**Test:** `teste/test_decode.py` (5 teste, toate trec; rulare: `python -m pytest`).

## Lucrarea B — Forensics pe fișiere (`forensics.py`) și LSB (`stego.py`)

**B1 Tipul real (magic bytes):** `foto.jpg` → jpeg (`ff d8`), `ascuns.png` → png
(`89 50 4e 47`). `xor.bin` și `mesaj.txt` nu au semnătură cunoscută (date brute / text).

**B2 strings (`ascuns.png`):** apar `tEXtComment`, indiciul „nu tot ce e in fisier se
vede in imagine", apoi `IEND` urmat de `secret.txt` și `PK`: după sfârșitul PNG-ului
mai urmează un alt fișier.

**B3 EXIF/GPS (`foto.jpg`):** Make = LabCam, Model = Model X1, DateTime =
2025:10:06 10:15:00. GPS brut: N 47°0′37.8″, E 28°51′49.68″ → **47.010500, 28.863800**
(în jurul Chișinăului). De aceea se șterge EXIF înainte de publicare.

**B4 File carving:** semnătura `PK\x03\x04` apare la octetul **452** (după `IEND`).
Arhiva extrasă conține `secret.txt` = `FLAG{fisier_ascuns_la_coada_png}`.

**B5–B6 LSB:** mesajul `FLAG{ascuns_in_pixeli}` (+ octet 0 terminator) e scris în
ultimul bit al canalelor R,G,B din `foto.jpg` și salvat ca `stego.png` (PNG, fără
pierderi; un JPG ar distruge biții). Dezvăluit: `FLAG{ascuns_in_pixeli}`.
Diferența maximă pe un canal față de original: 1 din 255, deci imaginea arată identic.

## Opțional — `challenge.bin` (`arsenal/forensics/challenge.py`)

Pași: (1) două linii ASCII; (2) linia 1 e base64 → octeți ne-citibili; (3) probabil XOR
cu un octet; (4) încerc cele 256 de chei; (5) linia 2 are 64 de caractere hex = sha256,
deci păstrez cheia al cărei rezultat are exact acel hash. Cheia = **91**;
flag = `FLAG{xor_si_base64_si_un_hash_de_verificat}`.
