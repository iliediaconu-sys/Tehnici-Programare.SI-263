from arsenal.forensics.decode import desfa, desfa_complet, ghici_strat, sparge_xor, sparge_hash
import hashlib


def test_base64():
    strat, b = desfa("U2FsdXQ=")
    assert strat == "base64"
    assert b == b"Salut"


def test_ghici():
    assert ghici_strat("%2Fetc") == "url"
    assert ghici_strat("48656c6c6f") == "hex"


def test_straturi_multiple():
    # "Salut" -> hex -> base64
    straturi, rez = desfa_complet("NTM2MTZjNzU3NA==")
    assert straturi == ["base64", "hex"]
    assert rez == b"Salut"


def test_xor_brute():
    clar = b"FLAG{test xor} un text lung destul"
    cifrat = bytes(b ^ 77 for b in clar)
    assert sparge_xor(cifrat)[0][1] == 77


def test_hash_dictionar():
    h = hashlib.md5(b"sunshine").hexdigest()
    assert sparge_hash(h) == ("md5", "sunshine")
