# Laborator: funcții, metode și importuri pe web
# Student: Diaconu Ilie
# Partea 2: Metode și atribute ale obiectelor web (exercițiile 9-20)

import time

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ---------------------------------------------------------------------------
# Exercițiul 9. Elementele de bază ale răspunsului
# ---------------------------------------------------------------------------
print("--- Exercițiul 9 ---")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)  # atribut (număr întreg)
print(response.ok)  # atribut (True dacă status < 400)
print(response.url)  # atribut (URL-ul final, după redirecționări)
print(response.encoding)  # atribut (codificarea textului, de ex. utf-8)
# Niciuna nu are paranteze: toate sunt atribute. Metodele (de ex.
# response.json()) se apelează cu paranteze.

# ---------------------------------------------------------------------------
# Exercițiul 10. Tratarea erorilor cu o metodă
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 10 ---")
response.raise_for_status()  # pagina principală există: nu se întâmplă nimic
print("Pagina principală este în regulă.")

time.sleep(1)
try:
    inexistent = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    inexistent.raise_for_status()  # ridică HTTPError pentru coduri 4xx/5xx
except requests.HTTPError as eroare:
    print("Pagina nu a fost găsită, dar programul continuă. Detalii:", eroare)

# ---------------------------------------------------------------------------
# Exercițiul 11. Toate antetele
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 11 ---")
for nume, valoare in response.headers.items():
    print(f"{nume}: {valoare}")

# ---------------------------------------------------------------------------
# Exercițiul 12. Metode de dicționar
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 12 ---")
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type (litere mici):", response.headers.get("content-type", "lipsește"))
# Observație: obținem aceeași valoare. response.headers nu este un dicționar
# obișnuit, ci un CaseInsensitiveDict: numele antetelor se caută fără să
# conteze literele mari/mici (în HTTP, numele antetelor nu țin cont de
# majuscule). Într-un dict normal, "content-type" nu ar fi găsit "Content-Type".

# ---------------------------------------------------------------------------
# Exercițiul 13. Înlănțuirea metodelor de șir
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 13 ---")
print("Apariții ale cuvântului 'cyber':", response.text.lower().count("cyber"))
# Putem înlănțui metodele pentru că .lower() returnează un șir NOU (str), iar
# orice str are metoda .count(). Rezultatul fiecărei metode este obiectul pe
# care se apelează următoarea metodă. (Șirurile sunt imutabile: .lower() nu
# modifică response.text, ci întoarce o copie.)

# ---------------------------------------------------------------------------
# Exercițiul 14. Găsirea titlului
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 14 ---")
html = response.text
start = html.find("<title>")
if start == -1:
    print("Pagina nu are tag <title>")
else:
    start += len("<title>")
    sfarsit = html.find("</title>", start)
    print("Titlu:", html[start:sfarsit].strip())

# ---------------------------------------------------------------------------
# Exercițiul 15. Numărarea liniilor
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 15 ---")
lines = html.splitlines()
print("Număr de linii:", len(lines))
if lines:
    print("Lungimea celei mai lungi linii:", len(max(lines, key=len)))

# ---------------------------------------------------------------------------
# Exercițiul 16. Verificarea HTTPS
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 16 ---")
if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")

# ---------------------------------------------------------------------------
# Exercițiul 17. Urmărirea redirecționărilor
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 17 ---")
time.sleep(1)
redirect = requests.get("http://cybercor.org", timeout=TIMEOUT)
for pas in redirect.history:
    print(pas.status_code, "->", pas.url)
print("URL final:", redirect.url)

# ---------------------------------------------------------------------------
# Exercițiul 18. HEAD versus GET
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 18 ---")
time.sleep(1)
cap = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
complet = requests.get(BASE_URL, timeout=TIMEOUT)
print("HEAD:", len(cap.content), "octeți")
print("GET: ", len(complet.content), "octeți")
# HEAD cere serverului doar codul de stare și antetele, fără corp, deci
# len(response.content) este 0. GET aduce și corpul paginii (codul HTML).
# HEAD e util când vrem doar să verificăm că o pagină există, fără să
# descărcăm tot conținutul.

# ---------------------------------------------------------------------------
# Exercițiul 19. Cookie-uri
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 19 ---")
if len(response.cookies) == 0:
    print("Niciun cookie setat")
else:
    for cookie in response.cookies:
        print(cookie.name, "- secure:", cookie.secure)

# ---------------------------------------------------------------------------
# Exercițiul 20. Sesiuni
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 20 ---")
time.sleep(1)
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Diaconu Ilie"})
raspuns = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print(raspuns.json())
primit = raspuns.json()["headers"].get("User-Agent")
print("Antetul User-Agent a fost trimis:", primit)

# Verificați-vă: de ce response.text nu are paranteze, iar response.json() are?
#   - response.text este un ATRIBUT (o proprietate): doar îi citim valoarea,
#     iar textul este deja disponibil, decodat din corpul răspunsului.
#   - response.json() este o METODĂ: ea FACE ceva, adică interpretează textul
#     ca JSON și construiește un dicționar/listă. Parantezele apelează
#     metoda; metoda poate și să eșueze (dacă răspunsul nu e JSON valid).
