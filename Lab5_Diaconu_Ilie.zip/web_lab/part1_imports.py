# Laborator: funcții, metode și importuri pe web
# Student: Diaconu Ilie
# Partea 1: Importuri (exercițiile 1-8)

import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


def pauza():
    """Pauză de 1 secundă între cereri (regula de lucru)."""
    time.sleep(1)


# ---------------------------------------------------------------------------
# Exercițiul 1. Primul import
# ---------------------------------------------------------------------------
print("--- Exercițiul 1 ---")
import requests

print("Versiunea requests:", requests.__version__)

import urllib.request

# Explicație: `urllib` face parte din biblioteca standard Python, adică vine
# instalat odată cu Python. `requests` este o bibliotecă externă (scrisă de
# alții și publicată pe PyPI), deci nu există în instalarea de bază și trebuie
# adusă cu `pip install requests`.

# ---------------------------------------------------------------------------
# Exercițiul 2. Două stiluri de import
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 2 ---")
# Stilul 1: import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (import requests):", response.status_code)

pauza()

# Stilul 2: from requests import get
from requests import get

response = get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (from requests import get):", response.status_code)

# Avantaj `import requests`: se vede mereu de unde vine funcția (requests.get),
# deci nu apar confuzii cu alte funcții numite `get` (de ex. dict.get).
# Avantaj `from requests import get`: codul este mai scurt, nu repetăm
# numele modulului la fiecare apel.

# ---------------------------------------------------------------------------
# Exercițiul 3. Alias-uri
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 3 ---")
pauza()
import requests as rq

response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (rq.get):", response.status_code)

# Un alias face codul mai ușor de citit când numele original e lung și
# aliasul este unul cunoscut de toată lumea (import numpy as np,
# import pandas as pd). Îl face mai greu de citit când aliasul e inventat sau
# prea scurt (rq, r, x): cine citește codul trebuie să ghicească ce este.

# ---------------------------------------------------------------------------
# Exercițiul 4. Doar biblioteca standard
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 4 ---")
pauza()
try:
    with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as raspuns:
        print("Status:", raspuns.status)
        corp = raspuns.read().decode("utf-8", errors="replace")
        print(corp[:200])
except OSError as eroare:  # URLError și HTTPError sunt subclase ale OSError
    print("Cererea urllib a eșuat:", eroare)

# ---------------------------------------------------------------------------
# Exercițiul 5. Priviți în interiorul unui modul
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 5 ---")
print(dir(requests))

# Trei nume din rezultat:
#   - get      -> o FUNCȚIE (requests.get(url) trimite o cerere GET)
#   - Session  -> o CLASĂ (requests.Session() creează un obiect sesiune)
#   - exceptions -> un MODUL (requests.exceptions conține clasele de erori)
for nume in ("get", "Session", "exceptions"):
    print(nume, "->", type(getattr(requests, nume)).__name__)

# ---------------------------------------------------------------------------
# Exercițiul 6. Citiți documentația
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 6 ---")
help(requests.get)
# Parametrul care setează timpul maxim de așteptare este `timeout`
# (documentat în requests.request, la care trimite get prin **kwargs).
pauza()
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cerere cu timeout:", response.status_code)

# ---------------------------------------------------------------------------
# Exercițiul 7. Cronometrarea unei cereri
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 7 ---")
pauza()
start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
durata = time.perf_counter() - start
print(f"time.perf_counter(): {durata:.3f} s")
print(f"response.elapsed:    {response.elapsed.total_seconds():.3f} s")
# perf_counter măsoară tot timpul din codul nostru (inclusiv rezolvarea DNS
# și crearea conexiunii), deci este de obicei puțin mai mare decât
# response.elapsed, care măsoară de la trimiterea cererii până la primirea
# antetelor răspunsului.

# ---------------------------------------------------------------------------
# Exercițiul 8. Când un import eșuează
# ---------------------------------------------------------------------------
print("\n--- Exercițiul 8 ---")
try:
    import bs4

    print("bs4 este instalat, versiunea", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# Verificați-vă: care este diferența dintre un modul, un pachet și o bibliotecă?
#   - modul     = un singur fișier .py (de ex. time.py, webtools.py);
#   - pachet    = un director cu mai multe module, care conține __init__.py
#                 (de ex. requests, urllib);
#   - bibliotecă = termen general: o colecție de cod reutilizabil (module și
#                 pachete) cu un scop comun, de ex. biblioteca requests sau
#                 biblioteca standard Python.
