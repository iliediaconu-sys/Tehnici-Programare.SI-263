# Laborator: funcții, metode și importuri pe web
# Student: Diaconu Ilie
# Partea 5: modulul meu, cu toate funcțiile reutilizabile (exercițiile 44-50)

import csv
import json
import re
import socket
import ssl
import time
import urllib.parse
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiul 47. Constantă de modul: antetele trimise la fiecare cerere.
DEFAULT_HEADERS = {"User-Agent": "WebLab-Diaconu Ilie"}

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


# ---------------------------------------------------------------------------
# Cereri de bază
# ---------------------------------------------------------------------------
def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă url (cu DEFAULT_HEADERS și timeout) și returnează răspunsul."""
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html: str) -> Optional[str]:
    """Returnează titlul paginii dintr-un șir HTML sau None dacă lipsește."""
    start = html.find("<title>")
    if start == -1:
        return None
    start += len("<title>")
    sfarsit = html.find("</title>", start)
    if sfarsit == -1:
        return None
    return html[start:sfarsit].strip()


def security_headers(url: str) -> Dict[str, bool]:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    headers = fetch(url).headers  # căutarea nu ține cont de litere mari/mici
    return {nume: nume in headers for nume in SECURITY_HEADERS}


def score_headers(results: Dict[str, bool]) -> str:
    """Returnează scorul antetelor de securitate ca șir, de exemplu "3/5"."""
    prezente = sum(1 for valoare in results.values() if valoare)
    return f"{prezente}/{len(results)}"


def check_paths(base: str, paths: List[str]) -> Dict[str, Optional[int]]:
    """Returnează {cale: cod_de_stare}; None dacă cererea a eșuat.

    Între cereri se face o pauză de 1 secundă.
    """
    rezultate: Dict[str, Optional[int]] = {}
    for i, path in enumerate(paths):
        if i > 0:
            time.sleep(1)
        try:
            rezultate[path] = get_status(base + path)
        except requests.RequestException:
            rezultate[path] = None
    return rezultate


# ---------------------------------------------------------------------------
# robots.txt
# ---------------------------------------------------------------------------
def fetch_robots(base: str) -> Optional[str]:
    """Returnează textul /robots.txt sau None dacă fișierul lipsește."""
    try:
        raspuns = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    if raspuns.status_code != 200:
        return None
    return raspuns.text


def disallowed_paths(robots_text: Optional[str]) -> List[str]:
    """Returnează valorile liniilor "Disallow:" (listă goală pentru None)."""
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.split("#", 1)[0].strip()
        if linie.lower().startswith("disallow:"):
            valoare = linie.split(":", 1)[1].strip()
            if valoare:
                cai.append(valoare)
    return cai


# ---------------------------------------------------------------------------
# Legături
# ---------------------------------------------------------------------------
def extract_links(html: str) -> List[str]:
    """Returnează legăturile (href) din html, fără duplicate, în ordinea din pagină."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))


def split_links(links: List[str], domain: str) -> Tuple[List[str], List[str]]:
    """Împarte legăturile în (interne, externe) față de `domain`.

    Legăturile care nu sunt http(s) (mailto:, tel:, javascript:) sunt ignorate.
    """
    baza = "https://" + domain
    interne, externe = [], []
    for legatura in links:
        complet = urllib.parse.urljoin(baza, legatura)
        parti = urllib.parse.urlparse(complet)
        if parti.scheme not in ("http", "https"):
            continue
        (interne if parti.netloc == domain else externe).append(complet)
    return interne, externe


# ---------------------------------------------------------------------------
# Rețea: redirecționări, DNS, certificat
# ---------------------------------------------------------------------------
def redirect_chain(url: str) -> List[Tuple[int, str]]:
    """Returnează lanțul de redirecționări ca listă de (cod, destinație).

    Pentru http://cybercor.org poate returna [(301, "https://cybercor.org/")].
    Lista este goală dacă nu a existat nicio redirecționare.
    """
    raspuns = fetch(url)
    pasi = raspuns.history + [raspuns]
    return [(pas.status_code, urllib.parse.urljoin(pas.url, pasi[i + 1].url))
            for i, pas in enumerate(pasi[:-1])]


def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a lui hostname (interogare DNS)."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            expirare = ssl.cert_time_to_seconds(ssock.getpeercert()["notAfter"])
    return int((expirare - time.time()) // 86400)


# ---------------------------------------------------------------------------
# Exercițiul 49. Raport CSV
# ---------------------------------------------------------------------------
def save_report_csv(results: Dict[str, Optional[int]], filename: str = "report.csv") -> None:
    """Salvează rezultatul lui check_paths() în CSV: path, status, checked_at."""
    with open(filename, "w", newline="", encoding="utf-8") as fisier:
        scriitor = csv.writer(fisier)
        scriitor.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            scriitor.writerow([path, "" if status is None else status,
                               datetime.now().isoformat()])


# ---------------------------------------------------------------------------
# Exercițiul 50. Proiect final
# ---------------------------------------------------------------------------
def _safe(functie, *args, default=None):
    """Apelează functie(*args); la o eroare de rețea returnează `default`.

    Astfel, o verificare care eșuează (de ex. certificat) nu oprește raportul.
    """
    try:
        return functie(*args)
    except (requests.RequestException, OSError) as eroare:  # OSError: DNS, TLS
        print(f"  (avertisment: {functie.__name__} a eșuat: {eroare})")
        return default


def site_report(url: str, output: str = "report.json") -> dict:
    """Colectează informații despre site, le afișează și le salvează în JSON.

    Folosește funcțiile din acest modul. Între cereri se face o pauză de 1 s.
    Returnează dicționarul raportului.
    """
    parti = urllib.parse.urlparse(url)
    hostname = parti.hostname or ""
    domain = parti.netloc
    base = f"{parti.scheme}://{domain}"

    raport: dict = {"url": url, "checked_at": datetime.now().isoformat()}

    # 1-2. Codul de stare, URL-ul final, titlul și legăturile (o singură cerere)
    raspuns = fetch(url)
    raport["status_code"] = raspuns.status_code
    raport["final_url"] = raspuns.url
    raport["title"] = get_title(raspuns.text)
    interne, externe = split_links(extract_links(raspuns.text), domain)
    raport["links_internal"] = len(interne)
    raport["links_external"] = len(externe)

    # 3. Adresa IP
    raport["ip"] = _safe(resolve, hostname)

    # 4. Lanțul de redirecționări pornind de la http://
    time.sleep(1)
    lant = _safe(redirect_chain, "http://" + domain, default=None)
    raport["redirects"] = (None if lant is None
                           else [{"status": cod, "to": tinta} for cod, tinta in lant])

    # 5. Scorul antetelor de securitate
    time.sleep(1)
    antete = _safe(security_headers, url, default=None)
    raport["security_headers"] = antete
    raport["security_score"] = None if antete is None else score_headers(antete)

    # 6. Zilele rămase până la expirarea certificatului
    time.sleep(1)
    raport["cert_days_left"] = (_safe(cert_days_left, hostname)
                                if parti.scheme == "https" else None)

    # 8. Căile interzise din robots.txt
    time.sleep(1)
    raport["disallowed_paths"] = disallowed_paths(fetch_robots(base))

    # --- Afișare ---
    print(f"=== Raport site: {url} ===")
    print("Cod de stare:", raport["status_code"], f"({raport['final_url']})")
    print("Titlu:", raport["title"])
    print("Adresă IP:", raport["ip"] or "necunoscută")
    if raport["redirects"] is None:
        print("Redirecționări: necunoscute")
    elif not raport["redirects"]:
        print("Redirecționări: niciuna")
    else:
        print("Redirecționări:",
              ", ".join(f"{r['status']} -> {r['to']}" for r in raport["redirects"]))
    print("Scor securitate:", raport["security_score"] or "necunoscut")
    if raport["cert_days_left"] is None:
        print("Certificat: necunoscut")
    else:
        print(f"Certificat: {raport['cert_days_left']} de zile rămase")
    print(f"Legături: {raport['links_internal']} interne, "
          f"{raport['links_external']} externe")
    print("Căi interzise:", ", ".join(raport["disallowed_paths"]) or "niciuna")

    with open(output, "w", encoding="utf-8") as fisier:
        json.dump(raport, fisier, indent=2, ensure_ascii=False)
    print(f"Salvat în {output}")
    return raport


# ---------------------------------------------------------------------------
# Exercițiul 46. Blocul main
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
