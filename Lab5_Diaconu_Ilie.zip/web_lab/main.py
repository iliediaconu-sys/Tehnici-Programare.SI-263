# Laborator: funcții, metode și importuri pe web
# Student: Diaconu Ilie
# Partea 5: programul principal, care importă modulul webtools (ex. 44-50)
#
# Rulare:  python main.py https://cybercor.org

import argparse
import time

# Exercițiul 44: importul întregului modul; funcțiile se apelează webtools.nume()
import webtools

# Exercițiile 45 și 47: importul unor nume anume, inclusiv o constantă
from webtools import DEFAULT_HEADERS, get_title, security_headers  # noqa: F401

# Exercițiul 45: dacă main.py ar avea și o funcție proprie `get_title`, definiția
# de mai jos în fișier ar înlocui numele importat: în main.py `get_title` ar
# însemna funcția noastră, iar cea din webtools ar deveni inaccesibilă prin
# acest nume (Python nu dă nicio eroare, ultima legare a numelui câștigă).
# Cu `import webtools` nu există conflict, pentru că webtools.get_title și
# get_title sunt nume diferite.

# Exercițiul 46: blocul `if __name__ == "__main__":` din webtools.py rulează
# doar la `python webtools.py`, când fișierul este programul principal și
# __name__ == "__main__". Când main.py face `import webtools`, __name__ din
# webtools devine "webtools", condiția e falsă și autotestul nu se execută.


def parse_args() -> argparse.Namespace:
    """Exercițiul 48: citește URL-ul din linia de comandă."""
    parser = argparse.ArgumentParser(
        description="Raport despre un site web (laborator Python)."
    )
    parser.add_argument("url", help="adresa site-ului, ex.: https://cybercor.org")
    return parser.parse_args()


def main() -> None:
    """Rulează exercițiile 44-50 pe URL-ul primit din linia de comandă."""
    args = parse_args()
    url = args.url.rstrip("/")

    print("--- Exercițiul 44 ---")
    print("Titlu:", webtools.get_title(webtools.fetch(url).text))

    print("\n--- Exercițiul 47 ---")
    print("DEFAULT_HEADERS =", DEFAULT_HEADERS)

    print("\n--- Exercițiul 49 ---")
    time.sleep(1)
    rezultate = webtools.check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
    webtools.save_report_csv(rezultate, "report.csv")
    print(rezultate)
    print("Salvat în report.csv")

    print("\n--- Exercițiul 50 ---")
    time.sleep(1)
    webtools.site_report(url)


if __name__ == "__main__":
    main()
