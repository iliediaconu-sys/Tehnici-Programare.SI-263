# Laborator: funcții, metode și importuri pe web
# Student: Diaconu Ilie
# Partea 3: Scrierea propriilor funcții (exercițiile 21-34)

import time
from typing import Dict, List, Optional

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# ---------------------------------------------------------------------------
# Exercițiile 21 și 23. Prima funcție + parametru implicit
# ---------------------------------------------------------------------------
def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă url și returnează obiectul răspuns (timeout implicit: 10 s)."""
    return requests.get(url, timeout=timeout)


# ---------------------------------------------------------------------------
# Exercițiul 22. Returnarea unei singure valori (+ exercițiul 26: adnotări)
# ---------------------------------------------------------------------------
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


# ---------------------------------------------------------------------------
# Exercițiile 24 și 25. O singură sarcină pe funcție + docstring
# ---------------------------------------------------------------------------
def get_title(html: str) -> Optional[str]:
    """Returnează titlul paginii dintr-un șir HTML.

    Caută textul dintre <title> și </title> și îl curăță cu .strip().
    Returnează None dacă pagina nu are titlu. Funcția nu face nicio
    operație de rețea: primește doar textul HTML.
    """
    start = html.find("<title>")
    if start == -1:
        return None
    start += len("<title>")
    sfarsit = html.find("</title>", start)
    if sfarsit == -1:
        return None
    return html[start:sfarsit].strip()


# ---------------------------------------------------------------------------
# Exercițiul 27. Fără opriri neașteptate
# ---------------------------------------------------------------------------
def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde cu un cod sub 400, altfel False.

    Orice eroare de rețea (domeniu inexistent, timeout etc.) duce la False,
    nu la oprirea programului.
    """
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


# ---------------------------------------------------------------------------
# Exercițiul 28. Returnarea unui dicționar
# ---------------------------------------------------------------------------
def check_paths(base: str, paths: List[str]) -> Dict[str, Optional[int]]:
    """Returnează {cale: cod_de_stare} pentru fiecare cale din listă.

    Dacă o cerere eșuează (eroare de rețea), codul de stare este None.
    Între cereri se face o pauză de 1 secundă.
    """
    rezultate: Dict[str, Optional[int]] = {}
    for i, path in enumerate(paths):
        if i > 0:
            time.sleep(1)
        try:
            rezultate[path] = get_status(base + path)
        except requests.RequestException:
            rezultate[path] = None
    return rezultate


# ---------------------------------------------------------------------------
# Exercițiul 29. Argumente cu nume
# ---------------------------------------------------------------------------
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului `name` al răspunsului de la url.

    Dacă antetul nu există, returnează valoarea `default`.
    """
    return fetch(url).headers.get(name, default)


# ---------------------------------------------------------------------------
# Exercițiul 30. Antete de securitate
# ---------------------------------------------------------------------------
SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


def security_headers(url: str) -> Dict[str, bool]:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate.

    True înseamnă că antetul este prezent în răspunsul de la url.
    """
    headers = fetch(url).headers  # CaseInsensitiveDict: litera mare/mică nu contează
    return {nume: nume in headers for nume in SECURITY_HEADERS}


# ---------------------------------------------------------------------------
# Exercițiul 31. Funcții care apelează funcții
# ---------------------------------------------------------------------------
def score_headers(results: Dict[str, bool]) -> str:
    """Primește dicționarul din security_headers() și returnează un scor, ex. "3/5"."""
    prezente = sum(1 for valoare in results.values() if valoare)
    return f"{prezente}/{len(results)}"


# ---------------------------------------------------------------------------
# Exercițiul 32. Două funcții, o sarcină
# ---------------------------------------------------------------------------
def fetch_robots(base: str) -> Optional[str]:
    """Returnează textul fișierului /robots.txt sau None dacă lipsește.

    None se returnează și când cererea eșuează (eroare de rețea).
    """
    try:
        raspuns = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    if raspuns.status_code != 200:
        return None
    return raspuns.text


def disallowed_paths(robots_text: Optional[str]) -> List[str]:
    """Returnează lista valorilor din liniile "Disallow:" ale unui robots.txt.

    Acceptă și None (fișier lipsă): în acest caz returnează o listă goală.
    Liniile Disallow goale (care nu interzic nimic) sunt ignorate.
    """
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.split("#", 1)[0].strip()  # eliminăm comentariile
        if linie.lower().startswith("disallow:"):
            valoare = linie.split(":", 1)[1].strip()
            if valoare:
                cai.append(valoare)
    return cai


# ---------------------------------------------------------------------------
# Exercițiul 33. Oricâte argumente
# ---------------------------------------------------------------------------
def response_times(*urls: str) -> Dict[str, float]:
    """Returnează {url: secunde} pentru oricâte URL-uri primește.

    Timpul este măsurat cu time.perf_counter(). Pauză de 1 s între cereri.
    """
    timpi = {}
    for i, url in enumerate(urls):
        if i > 0:
            time.sleep(1)
        start = time.perf_counter()
        fetch(url)
        timpi[url] = round(time.perf_counter() - start, 3)
    return timpi


# ---------------------------------------------------------------------------
# Exercițiul 34. Argumente cu nume colectate
# ---------------------------------------------------------------------------
def log(message: str, **details) -> None:
    """Afișează mesajul urmat de fiecare detaliu, separate prin " | "."""
    bucati = [message] + [f"{cheie}={valoare}" for cheie, valoare in details.items()]
    print(" | ".join(bucati))


# ===========================================================================
# Apeluri (fiecare funcție este apelată cel puțin o dată)
# ===========================================================================
if __name__ == "__main__":
    print("--- Exercițiul 21 ---")
    raspuns = fetch(BASE_URL)
    print("Cod de stare:", raspuns.status_code)

    print("\n--- Exercițiul 22 ---")
    for cale in ["/", "/robots.txt", "/sitemap.xml"]:
        time.sleep(1)
        print(cale, "->", get_status(BASE_URL + cale))

    print("\n--- Exercițiul 23 ---")
    time.sleep(1)
    print("Cu timeout implicit:", fetch(BASE_URL).status_code)
    time.sleep(1)
    print("Cu timeout=3:", fetch(BASE_URL, timeout=3).status_code)

    print("\n--- Exercițiul 24 ---")
    print("Titlu:", get_title(raspuns.text))

    print("\n--- Exercițiul 25 ---")
    help(get_title)

    print("\n--- Exercițiul 26 ---")
    # Adnotările de tip sunt doar indicii pentru oameni și pentru editoare:
    # Python NU le verifică la rulare. get_status(123) trece de adnotare și
    # eșuează abia în requests (URL invalid: "No scheme supplied"). Deci
    # NU, adnotările nu ne opresc să apelăm funcția cu un tip greșit.
    try:
        get_status(123)  # type: ignore[arg-type]
    except requests.RequestException as eroare:
        print("get_status(123) a eșuat în requests, nu din cauza adnotării:")
        print("  ", type(eroare).__name__, "-", eroare)

    print("\n--- Exercițiul 27 ---")
    time.sleep(1)
    print(BASE_URL, "->", page_exists(BASE_URL))
    print("domeniu inexistent ->", page_exists("https://this-domain-does-not-exist.invalid"))

    print("\n--- Exercițiul 28 ---")
    time.sleep(1)
    print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))

    print("\n--- Exercițiul 29 ---")
    time.sleep(1)
    print("Server:", get_header(BASE_URL, name="Server"))

    print("\n--- Exercițiul 30 ---")
    time.sleep(1)
    print(security_headers(BASE_URL))

    print("\n--- Exercițiul 31 ---")
    time.sleep(1)
    print("Scor:", score_headers(security_headers(BASE_URL)))

    print("\n--- Exercițiul 32 ---")
    time.sleep(1)
    robots = fetch_robots(BASE_URL)
    print("Căi interzise:", disallowed_paths(robots))
    print("Cu None:", disallowed_paths(None))

    print("\n--- Exercițiul 33 ---")
    time.sleep(1)
    print(response_times(BASE_URL, BASE_URL + "/robots.txt"))

    print("\n--- Exercițiul 34 ---")
    log("verificat", url=BASE_URL, status=200)

    # Verificați-vă: print() în interiorul unei funcții vs. return.
    #   - print() doar AFIȘEAZĂ o valoare pe ecran; după ce funcția se termină,
    #     programul nu mai are acea valoare (funcția returnează None).
    #   - return TRANSMITE valoarea apelantului, care o poate stoca într-o
    #     variabilă, o poate folosi în alt calcul sau o poate afișa singur.
    #     De aceea score_headers(security_headers(...)) funcționează: fiecare
    #     funcție returnează ceva ce următoarea poate folosi.
