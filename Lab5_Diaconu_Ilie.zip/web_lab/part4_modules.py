# Laborator: funcții, metode și importuri pe web
# Student: Diaconu Ilie
# Partea 4: Alte module din biblioteca standard (exercițiile 35-43)

import hashlib
import json
import re
import socket
import ssl
import time
import urllib.parse
from html.parser import HTMLParser
from typing import List, Tuple

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# ---------------------------------------------------------------------------
# Exercițiul 35. Descompunerea unui URL
# ---------------------------------------------------------------------------
def show_url_parts(url: str) -> None:
    """Afișează părțile unui URL: scheme, netloc, path, query, fragment."""
    parti = urllib.parse.urlparse(url)
    print("scheme:  ", parti.scheme)
    print("netloc:  ", parti.netloc)
    print("path:    ", parti.path)
    print("query:   ", parti.query)
    print("fragment:", parti.fragment)


# ---------------------------------------------------------------------------
# Exercițiul 37. Extragerea legăturilor
# ---------------------------------------------------------------------------
def extract_links(html: str) -> List[str]:
    """Returnează legăturile (valorile href) din html, fără duplicate.

    Ordinea din pagină este păstrată.
    """
    legaturi = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(legaturi))  # dict păstrează ordinea => fără duplicate


# ---------------------------------------------------------------------------
# Exercițiul 38. Interne sau externe?
# ---------------------------------------------------------------------------
def split_links(links: List[str], domain: str) -> Tuple[List[str], List[str]]:
    """Împarte legăturile în (interne, externe) față de `domain`.

    Legăturile relative sunt transformate mai întâi în URL-uri complete cu
    urljoin(). Legăturile care nu sunt http(s) (mailto:, tel:, javascript:)
    nu sunt pagini web și sunt ignorate.
    """
    baza = "https://" + domain
    interne, externe = [], []
    for legatura in links:
        complet = urllib.parse.urljoin(baza, legatura)
        parti = urllib.parse.urlparse(complet)
        if parti.scheme not in ("http", "https"):
            continue
        if parti.netloc == domain:
            interne.append(complet)
        else:
            externe.append(complet)
    return interne, externe


# ---------------------------------------------------------------------------
# Exercițiul 39. Propriile metode: un parser HTML
# ---------------------------------------------------------------------------
class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img> din pagină."""

    def __init__(self):
        """Pregătește parserul și lista goală în care se strâng imaginile."""
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Apelată de parser la fiecare tag de deschidere; reține src de la <img>."""
        # HTMLParser scrie numele tag-urilor și ale atributelor cu litere mici,
        # deci <IMG SRC="..."> ajunge aici ca tag="img", attrs=[("src", ...)].
        if tag == "img":
            src = dict(attrs).get("src")
            if src:  # ignorăm <img> fără src (None) sau cu src gol
                self.images.append(src)


# ---------------------------------------------------------------------------
# Exercițiul 40. Amprenta paginii
# ---------------------------------------------------------------------------
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 (hexazecimal) a corpului paginii de la url."""
    raspuns = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(raspuns.content).hexdigest()


# ---------------------------------------------------------------------------
# Exercițiul 42. Interogare DNS
# ---------------------------------------------------------------------------
def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a lui hostname (interogare DNS)."""
    return socket.gethostbyname(hostname)


# ---------------------------------------------------------------------------
# Exercițiul 43. Expirarea certificatului
# ---------------------------------------------------------------------------
def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS.

    Se conectează la portul 443, citește certificatul serverului și compară
    data "notAfter" cu momentul curent. Rezultatul e negativ dacă a expirat.
    """
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            expirare = ssl.cert_time_to_seconds(ssock.getpeercert()["notAfter"])
    return int((expirare - time.time()) // 86400)


# ===========================================================================
# Apeluri
# ===========================================================================
if __name__ == "__main__":
    print("--- Exercițiul 35 ---")
    show_url_parts("https://cybercor.org/path?x=1#top")

    print("\n--- Exercițiul 36 ---")
    for relativ in ["/about", "contact.html", "../index.html"]:
        print(relativ, "->", urllib.parse.urljoin(BASE_URL, relativ))

    pagina = requests.get(BASE_URL, timeout=TIMEOUT)
    html = pagina.text

    print("\n--- Exercițiul 37 ---")
    legaturi = extract_links(html)
    print(len(legaturi), "legături unice")
    print(legaturi[:10])

    print("\n--- Exercițiul 38 ---")
    interne, externe = split_links(legaturi, "cybercor.org")
    print(len(interne), "interne,", len(externe), "externe")

    print("\n--- Exercițiul 39 ---")
    test_html = """
    <html><body>
    <img src="/logo.png" alt="Logo">
    <IMG SRC="poza.jpg">
    <img alt="imagine fără src">
    <img src="https://cdn.example.com/banner.webp" />
    <a href="/despre">Aceasta nu este o imagine</a>
    </body></html>
    """
    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)
    assert finder.images == [
        "/logo.png",  # imagine obișnuită
        "poza.jpg",  # tag scris cu majuscule
        "https://cdn.example.com/banner.webp",  # tag care se închide singur
    ], "Parserul nu a găsit exact imaginile așteptate"
    print("Testul a trecut!")

    # Acum parserul rulează pe pagina reală (reutilizăm răspunsul de mai sus).
    finder = ImageFinder()
    finder.feed(pagina.text)
    print(len(finder.images), "imagini găsite")
    for src in finder.images:
        print(src)
    print("Verificare: <img apare de", pagina.text.lower().count("<img"), "ori în sursă")

    print("\n--- Exercițiul 40 ---")
    time.sleep(1)
    amprenta1 = page_fingerprint(BASE_URL)
    time.sleep(1)
    amprenta2 = page_fingerprint(BASE_URL)
    print(amprenta1)
    print(amprenta2)
    print("Identice:", amprenta1 == amprenta2)
    # Amprentele ar fi diferite dacă pagina s-a schimbat între cereri: conținut
    # dinamic (oră, contor de vizitatori, token CSRF, reclame, recomandări),
    # o actualizare a site-ului sau o versiune diferită servită de CDN/server.
    # Chiar și un singur octet modificat schimbă complet hash-ul.

    print("\n--- Exercițiul 41 ---")
    with open("headers.json", "w", encoding="utf-8") as fisier:
        json.dump(dict(pagina.headers), fisier, indent=2)
    with open("headers.json", encoding="utf-8") as fisier:
        incarcat = json.load(fisier)
    primul = next(iter(incarcat), None)
    if primul:
        print(primul, "=", incarcat[primul])

    print("\n--- Exercițiul 42 ---")
    print("cybercor.org ->", resolve("cybercor.org"))

    print("\n--- Exercițiul 43 ---")
    print("Zile rămase:", cert_days_left("cybercor.org"))

    # Verificați-vă: în exercițiul 39, cine apelează handle_starttag()?
    # O apelează parserul însuși, din interiorul metodei feed(): pe măsură ce
    # citește HTML-ul, la fiecare tag de deschidere găsit apelează
    # self.handle_starttag(tag, attrs). Noi doar suprascriem metoda și
    # decidem ce se întâmplă (principiul "nu ne sunați noi, vă sunăm noi").
